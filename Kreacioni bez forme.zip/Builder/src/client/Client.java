/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import builder.Assistant;
import concrete_builder.KomBankOffer;
import concrete_builder.RaiffeisenOffer;
import concrete_builder.UnicreditOffer;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    Assistant as;
    
    Client(Assistant as)
    {
        this.as = as;
    }
    
    void Construct()
    {
        as.getBank();
        as.getLoan();
        as.createOffer();
    }
    
    public static void main(String[] args) {
        Client cl;
        
        UnicreditOffer uo = new UnicreditOffer();
        cl = new Client(uo);
        cl.Construct();
        System.out.println("First offer: " + uo.returnOffer());
        
        RaiffeisenOffer ro = new RaiffeisenOffer();
        cl = new Client(ro);
        cl.Construct();
        System.out.println("Second offer: " + ro.returnOffer());
        
        KomBankOffer ko = new KomBankOffer();
        cl = new Client(ko);
        cl.Construct();
        System.out.println("Third offer: " + ko.returnOffer());
    }
}
