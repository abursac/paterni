/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_factory;

import abstract_factory.Assistant;
import abstract_product.Bank;
import concrete_product.HomeLoan;
import concrete_product.UnicreditBank;
import offer.IOffer;
import offer.Offer;

/**
 *
 * @author Aleksandar
 */
public class UnicreditOffer extends Assistant{

    @Override
    public Offer createOffer() 
    {
        o = new Offer();
        b = new UnicreditBank();
        l = new HomeLoan();
        o.offer = "Bank: " + b.returnBank() + " Loan: " + l.returnLoan();
        return o;
    }

    
    
}
