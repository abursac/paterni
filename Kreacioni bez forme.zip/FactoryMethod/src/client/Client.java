/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import abstract_factory.Assistant;
import concrete_factory.KomBankOffer;
import concrete_factory.RaiffeisenOffer;
import concrete_factory.UnicreditOffer;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    Assistant as;
        
    Client(Assistant as)
    {
        this.as = as;
    }
    
    void create()
    {
        as.createOffer();
    }
    
    public static void main(String[] args) 
    {
        Client cl;
        
        UnicreditOffer uo = new UnicreditOffer();
        cl = new Client(uo);
        cl.create();
        System.out.println("First offer: " + uo.getOffer());
        
        RaiffeisenOffer ro = new RaiffeisenOffer();
        cl = new Client(ro);
        cl.create();
        System.out.println("Second offer: " + ro.getOffer());
        
        KomBankOffer ko = new KomBankOffer();
        cl = new Client(ko);
        cl.create();
        System.out.println("Third offer: " + ko.getOffer());
    }
}
