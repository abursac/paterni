/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstract_factory;

import abstract_product.Bank;
import abstract_product.Loan;

/**
 *
 * @author Aleksandar
 */
public interface Assistant 
{
    public Bank getBank();
    public Loan getLoan();
}
