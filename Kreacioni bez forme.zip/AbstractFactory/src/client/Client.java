/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import abstract_factory.Assistant;
import abstract_product.Bank;
import abstract_product.Loan;
import concrete_factory.KomBankOffer;
import concrete_factory.RaiffeisenOffer;
import concrete_factory.UnicreditOffer;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    Assistant as;
    Bank b;
    Loan l;
    Offer o;
    
    Client(Assistant as)
    {
        this.as = as;
        o = new Offer();
    }
    
    String create()
    {
        b = as.getBank();
        l = as.getLoan();
        o.offer = "Bank: " + b.returnBank() + " - Loan: " + l.returnLoan();
        return o.offer;
    }
    
    public static void main(String[] args) 
    {
        Client cl;
        
        UnicreditOffer uo = new UnicreditOffer();
        cl = new Client(uo);
        System.out.println("First offer: " + cl.create());
        
        RaiffeisenOffer ro = new RaiffeisenOffer();
        cl = new Client(ro);
        System.out.println("Second offer: " + cl.create());
        
        KomBankOffer ko = new KomBankOffer();
        cl = new Client(ko);
        System.out.println("Third offer: " + cl.create());
    }
}
