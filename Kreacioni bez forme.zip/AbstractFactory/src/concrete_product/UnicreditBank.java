/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_product;

import abstract_product.Bank;

/**
 *
 * @author Aleksandar
 */
public class UnicreditBank implements Bank
{

    @Override
    public String returnBank() 
    {
        return "Unicredit Bank";
    }
    
}
