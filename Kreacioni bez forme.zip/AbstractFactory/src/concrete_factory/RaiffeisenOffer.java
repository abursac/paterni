/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_factory;

import abstract_factory.Assistant;
import abstract_product.Bank;
import abstract_product.Loan;
import concrete_product.BussinessLoan;
import concrete_product.RaiffeisenBank;

/**
 *
 * @author Aleksandar
 */
public class RaiffeisenOffer implements Assistant
{

    @Override
    public Bank getBank() 
    {
        return new RaiffeisenBank();
    }

    @Override
    public Loan getLoan() 
    {
        return new BussinessLoan();
    }
    
}
