/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_factory;

import abstract_factory.Assistant;
import abstract_product.Bank;
import abstract_product.Loan;
import concrete_product.EducationLoan;
import concrete_product.KomBank;

/**
 *
 * @author Aleksandar
 */
public class KomBankOffer implements Assistant
{

    @Override
    public Bank getBank() 
    {
        return new KomBank();
    }

    @Override
    public Loan getLoan() 
    {
        return new EducationLoan();
    }
    
}
