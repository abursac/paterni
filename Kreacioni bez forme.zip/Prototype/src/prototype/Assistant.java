/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

import abstract_product.Bank;
import abstract_product.Loan;
import client.Offer;

/**
 *
 * @author Aleksandar
 */
public abstract class Assistant 
{
    public Bank b;
    public Loan l;
    public Offer o;
    
    public abstract void getBank();
    public abstract void getLoan();
    public abstract void createOffer();
    public abstract String returnOffer();
    public abstract Assistant clone();
}
