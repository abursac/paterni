/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import prototype.Assistant;
import concrete_prototype.KomBankOffer;
import concrete_prototype.RaiffeisenOffer;
import concrete_prototype.UnicreditOffer;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    Assistant as;
    
    Client(Assistant as)
    {
        this.as = as;
    }
    
    void Construct()
    {
        as.getBank();
        as.getLoan();
        as.createOffer();
    }
    
    public static void main(String[] args) {
        Client cl;
        
        UnicreditOffer uo = new UnicreditOffer();
        cl = new Client(uo);
        cl.Construct();
        System.out.println("First offer: " + uo.returnOffer());
        Assistant a1 = uo.clone();
        System.out.println("First offer - copy: " + a1.returnOffer());
        
        RaiffeisenOffer ro = new RaiffeisenOffer();
        cl = new Client(ro);
        cl.Construct();
        System.out.println("Second offer: " + ro.returnOffer());
        Assistant a2 = ro.clone();
        System.out.println("Second offer - copy: " + a2.returnOffer());
        
        KomBankOffer ko = new KomBankOffer();
        cl = new Client(ko);
        cl.Construct();
        System.out.println("Third offer: " + ko.returnOffer());
        Assistant a3 = ko.clone();
        System.out.println("Third offer - copy: " + a3.returnOffer());
    }
}
