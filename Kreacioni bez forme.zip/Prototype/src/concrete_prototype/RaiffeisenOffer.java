/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_prototype;

import prototype.Assistant;
import client.Offer;
import concrete_product.BussinessLoan;
import concrete_product.RaiffeisenBank;

/**
 *
 * @author Aleksandar
 */
public class RaiffeisenOffer extends Assistant
{

    public RaiffeisenOffer() 
    {
        o = new Offer();
    }

    public RaiffeisenOffer(RaiffeisenOffer ro)
    {
        o = new Offer();
        o.offer = ro.o.offer;
    }
    
    @Override
    public void getBank() 
    {
        b = new RaiffeisenBank();
    }

    @Override
    public void getLoan() 
    {
        l = new BussinessLoan();
    }

    @Override
    public void createOffer() 
    {
        o.offer = "Bank: " + b.returnBank() + " Loan: " + l.returnLoan();
    }

    @Override
    public String returnOffer() 
    {
        return o.offer;
    }

    @Override
    public Assistant clone() 
    {
        return new RaiffeisenOffer(this);
    }
    
    
}
