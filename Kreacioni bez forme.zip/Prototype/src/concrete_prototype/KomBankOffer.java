/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_prototype;

import prototype.Assistant;
import client.Offer;
import concrete_product.EducationLoan;
import concrete_product.KomBank;

/**
 *
 * @author Aleksandar
 */
public class KomBankOffer extends Assistant
{

    public KomBankOffer() 
    {
        o = new Offer();
    }
    
    public KomBankOffer(KomBankOffer ko)
    {
        o = new Offer();
        o.offer = ko.o.offer;
    }
    
    @Override
    public void getBank() 
    {
        b = new KomBank();
    }

    @Override
    public void getLoan() 
    {
        l = new EducationLoan();
    }

    @Override
    public void createOffer() 
    {
        o.offer = "Bank: " + b.returnBank() + " Loan: " + l.returnLoan();
    }

    @Override
    public String returnOffer() 
    {
        return o.offer;
    }

    @Override
    public Assistant clone() 
    {
        return new KomBankOffer(this);
    }
    
    
}
