/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_decorator;

import component.ManagementTeam;
import decorator.Staff;

/**
 *
 * @author Aleksandar
 */
public class MikelArteta extends Staff
{
    ManagementTeam mt;

    public MikelArteta(ManagementTeam mt) {
        this.mt = mt;
    }
    
    
    
    @Override
    public String getDescription() 
    {
        return mt.getDescription() + " Mastermind in positional game.";
    }

    @Override
    public int getCost() 
    {
        return 200 + mt.getCost();
    }
    
}
