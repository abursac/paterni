/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_product;

import abstract_product.Loan;

/**
 *
 * @author Aleksandar
 */
public class EducationLoan implements Loan
{

    @Override
    public String returnLoan() 
    {
        return "Education loan";
    }
    
}
