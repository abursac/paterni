/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_factory;

import abstract_factory.Assistant;
import abstract_product.Bank;
import abstract_product.Loan;
import concrete_product.HomeLoan;
import concrete_product.UnicreditBank;

/**
 *
 * @author Aleksandar
 */
public class UnicreditOffer implements Assistant
{

    @Override
    public Bank getBank() 
    {
        return new UnicreditBank();
    }

    @Override
    public Loan getLoan() 
    {
        return new HomeLoan();
    }
    
}
