/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import abstract_factory.Assistant;
import abstract_product.Bank;
import abstract_product.Loan;
import concrete_factory.KomBankOffer;
import concrete_factory.RaiffeisenOffer;
import concrete_factory.UnicreditOffer;
import forme.Forma;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    Assistant as;
    Bank b;
    Loan l;
    Offer o;
    
    public Client(Assistant as)
    {
        this.as = as;
        o = new Offer();
    }
    
    public String create()
    {
        b = as.getBank();
        l = as.getLoan();
        o.offer = "Bank: " + b.returnBank() + " - Loan: " + l.returnLoan();
        return o.offer;
    }
    
    public static void main(String[] args) 
    {
        Forma f = new Forma();
        f.setVisible(true);
    }
}
