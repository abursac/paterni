/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_command;

import command.Command;
import receiver.Stereo;

/**
 *
 * @author Aleksandar
 */
public class StereoOnWithCDCommand implements Command{
    Stereo stereo; 
     public StereoOnWithCDCommand(Stereo stereo) 
     { 
         this.stereo = stereo; 
     } 
     public String execute() 
     { 
         String text = "";
         
         text += stereo.on() + "\n"; 
         text += stereo.setCD() + "\n"; 
         text += stereo.setVolume(11) + "\n";
         return text;
     } 
}
