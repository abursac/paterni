/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_command;

import command.Command;
import receiver.Light;

/**
 *
 * @author Aleksandar
 */
public class LightOnCommand implements Command
{
    Light light; 

    public LightOnCommand(Light light) 
    { 
       this.light = light; 
    } 
    @Override
    public String execute() 
    { 
       return light.on(); 
    } 
}
