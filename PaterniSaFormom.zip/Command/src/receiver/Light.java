/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package receiver;

/**
 *
 * @author Aleksandar
 */
public class Light 
{
    public String on() 
    { 
        return "Light is on"; 
    } 
    public String off() 
    { 
        return "Light is off"; 
    } 
}
