/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package receiver;

/**
 *
 * @author Aleksandar
 */
public class Stereo 
{
    public String on() 
    { 
        return "Stereo is on"; 
    } 
    public String off() 
    { 
        return "Stereo is off"; 
    } 
    public String setCD() 
    { 
        return "Stereo is set " + "for CD input"; 
    } 
    public String setDVD() 
    { 
        return "Stereo is set" + " for DVD input)"; 
    } 
    public String setRadio() 
    { 
        return "Stereo is set" + " for Radio"; 
    } 
    public String setVolume(int volume) 
    { 
        return "Stereo volume set" + " to " + volume; 
    } 
}
