/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package handler;

/**
 *
 * @author Aleksandar
 */
public abstract class Player 
{
    public static int DEFENDER = 1;
    public static int MIDFIELDER = 2;
    public static int FORWARD = 3;
    
    protected int level;
    
    protected Player nextPlayer;

    public void setNextPlayer(Player nextPlayer) {
        this.nextPlayer = nextPlayer;
    }
    
    public String logMessage(int level, String message){
        String text = "";
      if(this.level <= level){
         text += write(message) + "\n";
      }
      if(nextPlayer != null){
         text += nextPlayer.logMessage(level, message);
      }
      return text;
   }

   abstract protected String write(String message);
}
