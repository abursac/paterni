/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import concrete_handler.Defender;
import concrete_handler.Forward;
import concrete_handler.Midfielder;
import forme.Forma;
import handler.Player;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    public static void main(String[] args) {
        Forma f = new Forma();
        f.setVisible(true);
    }
}
