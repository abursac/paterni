/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import prototype.Assistant;
import concrete_prototype.KomBankOffer;
import concrete_prototype.RaiffeisenOffer;
import concrete_prototype.UnicreditOffer;
import forme.Forma;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    Assistant as;
    
    public Client(Assistant as)
    {
        this.as = as;
    }
    
    public void Construct()
    {
        as.getBank();
        as.getLoan();
        as.createOffer();
    }
    
    public static void main(String[] args) {
        Forma f = new Forma();
        f.setVisible(true);
    }
}
