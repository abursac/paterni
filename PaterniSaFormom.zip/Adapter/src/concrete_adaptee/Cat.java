/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_adaptee;

import adaptee.Animal;

/**
 *
 * @author Aleksandar
 */
public class Cat implements Animal{

    @Override
    public String move() 
    {
        return "Jumping";
    }

    @Override
    public String makeSound() 
    {
        return "Meowing!";
    }
    
}
