/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import adapter.AnimalAdapter;
import concrete_adaptee.Cat;
import concrete_adaptee.Dog;
import forme.Forma;
import target.AnimalToy;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    public static void main(String[] args) {
        Forma f = new Forma();
        f.setVisible(true);
    }
}
