/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facade;

import subsistem_classes.Athlete;
import subsistem_classes.Basketballer;
import subsistem_classes.Footballer;
import subsistem_classes.Tenniser;

/**
 *
 * @author Aleksandar
 */
public class AthleteFacade 
{
    private Athlete athlete1 = new Footballer();
    private Athlete athlete2 = new Basketballer();
    private Athlete athlete3 = new Tenniser();
    
    public String playFootball()
    {
        return athlete1.play();
    }
    
    public String playBasketball()
    {
        return athlete2.play();
    }
    
    public String playTennis()
    {
        return athlete3.play();
    }
}
