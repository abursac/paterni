/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import abstract_factory.Assistant;
import concrete_factory.KomBankOffer;
import concrete_factory.RaiffeisenOffer;
import concrete_factory.UnicreditOffer;
import forme.Forma;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    Assistant as;
        
    public Client(Assistant as)
    {
        this.as = as;
    }
    
    public void create()
    {
        as.createOffer();
    }
    
    public static void main(String[] args) 
    {
        Forma f = new Forma();
        f.setVisible(true);
    }
}
