/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstract_factory;

import abstract_product.Bank;
import abstract_product.Loan;
import offer.Offer;

/**
 *
 * @author Aleksandar
 */
public abstract class Assistant {
    public Bank b;
    public Loan l;
    public Offer o;
    
    void create()
    {
        o = (Offer) createOffer();
    }

    public abstract Offer createOffer();
    
    public String getOffer()
    {
        return o.vratiPonudu();
    }
}
