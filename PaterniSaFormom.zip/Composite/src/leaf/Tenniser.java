/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leaf;

import component.Athlete;

/**
 *
 * @author Aleksandar
 */
public class Tenniser implements Athlete
{
    String name;
    int id;

    public Tenniser(String name, int id) {
        this.name = name;
        this.id = id;
    }
    
    

    @Override
    public String showAthleteInfo() 
    {
        return id + ". " + name;
    }
    
}
