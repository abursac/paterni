/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package composite;

import component.Athlete;
import java.util.ArrayList;

/**
 *
 * @author Aleksandar
 */
public class FootballTeam implements Athlete{

    ArrayList<Athlete> playerList = new ArrayList<>();
    
    @Override
    public String showAthleteInfo() 
    {
        String info = "";
        for(Athlete a: playerList)
        {
            info += a.showAthleteInfo();
            info += "\n";
        }
        return info;
    }
    
    public void addAthlete(Athlete a)
    {
        playerList.add(a);
    }
    
    public void removeAthlete(Athlete a)
    {
        playerList.remove(a);
    }
}
