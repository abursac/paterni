/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import Proxy.ProxyTeam;
import Subject.Team;
import forme.Forma;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aleksandar
 */
public class Client {
    public static void main(String[] args) {
        Forma f = new Forma();
        f.setVisible(true);
    }
}
