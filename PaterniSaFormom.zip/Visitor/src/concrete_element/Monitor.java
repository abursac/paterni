/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_element;

import element.ComputerPart;
import visitor.ComputerPartVisitor;

/**
 *
 * @author Aleksandar
 */
public class Monitor implements ComputerPart
{
    @Override
    public String accept(ComputerPartVisitor computerPartVisitor) 
    {
       return computerPartVisitor.visit(this);
    }
}
