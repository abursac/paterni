/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_visitor;

import concrete_element.Computer;
import concrete_element.KeyBoard;
import concrete_element.Monitor;
import concrete_element.Mouse;
import visitor.ComputerPartVisitor;

/**
 *
 * @author Aleksandar
 */
public class ComputerPartDisplayVisitor implements ComputerPartVisitor
{
    @Override
   public String visit(Computer computer) {
      return "Displaying Computer.";
   }

   @Override
   public String visit(Mouse mouse) {
      return "Displaying Mouse.";
   }

   @Override
   public String visit(KeyBoard keyboard) {
      return "Displaying Keyboard.";
   }

   @Override
   public String visit(Monitor monitor) {
      return "Displaying Monitor.";
   }
}
