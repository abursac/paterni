/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package element;

import visitor.ComputerPartVisitor;

/**
 *
 * @author Aleksandar
 */
public interface ComputerPart {
    public String accept(ComputerPartVisitor computerPartVisitor);
}
