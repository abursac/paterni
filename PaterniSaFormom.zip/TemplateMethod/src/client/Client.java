/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import abstract_class.Player;
import concrete_class.Basketballer;
import concrete_class.Footballer;
import concrete_class.Tenniser;
import forme.Forma;

/**
 *
 * @author Aleksandar
 */
public class Client {
    public static void main(String[] args) {
        Forma f = new Forma();
        f.setVisible(true);
    }
}
