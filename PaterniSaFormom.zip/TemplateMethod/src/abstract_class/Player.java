/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstract_class;

/**
 *
 * @author Aleksandar
 */
public abstract class Player {
    public abstract String train();
    public abstract String compete();
    public abstract String win();
    
    public final String doTheProcess()
    {
        String text = "";
        text += train() + "\n";
        text += compete() + "\n";
        text += win() + "\n";
        return text;
    }
}
