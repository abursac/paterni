/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_class;

import abstract_class.Player;

/**
 *
 * @author Aleksandar
 */
public class Basketballer extends Player
{
    @Override
    public String train() 
    {
        return "Practicing three pointers...";
    }

    @Override
    public String compete() 
    {
        return "Playing in NBA Finals...";
    }

    @Override
    public String win() 
    {
        return "Winning the ring!";
    }
}
