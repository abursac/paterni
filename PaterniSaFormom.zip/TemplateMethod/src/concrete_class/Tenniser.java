/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_class;

import abstract_class.Player;

/**
 *
 * @author Aleksandar
 */
public class Tenniser extends Player
{
    @Override
    public String train() 
    {
        return "Practicing serve...";
    }

    @Override
    public String compete() 
    {
        return "Playing in a Grand Slam...";
    }

    @Override
    public String win() 
    {
        return "Winning Wimbledon!";
    }
}
