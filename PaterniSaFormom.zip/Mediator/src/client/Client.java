/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_colleague.Flight;
import concrete_colleague.Runway;
import concrete_mediator.ATCMediator;
import forme.Forme;
import mediator.IATCMediator;

/**
 *
 * @author Aleksandar
 */
public class Client {
    public static void main(String args[])  
    { 
        Forme f = new Forme();
        f.setVisible(true);
    } 
}
