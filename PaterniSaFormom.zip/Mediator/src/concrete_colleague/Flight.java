/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_colleague;

import colleague.Command;
import mediator.IATCMediator;

/**
 *
 * @author Aleksandar
 */
public class Flight implements Command{
    private IATCMediator atcMediator; 
  
    public Flight(IATCMediator atcMediator)  
    { 
        this.atcMediator = atcMediator; 
    } 
  
    public String land()  
    { 
        if (atcMediator.isLandingOk())  
        { 
            atcMediator.setLandingStatus(true); 
            return "Successfully Landed."; 
        } 
        else
            return "Waiting for landing."; 
    } 
  
    public String getReady()  
    { 
        return "Ready for landing."; 
    } 
}
