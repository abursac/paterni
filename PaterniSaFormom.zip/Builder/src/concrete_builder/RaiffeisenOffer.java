/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_builder;

import builder.Assistant;
import client.Offer;
import concrete_product.BussinessLoan;
import concrete_product.RaiffeisenBank;

/**
 *
 * @author Aleksandar
 */
public class RaiffeisenOffer extends Assistant
{

    public RaiffeisenOffer() 
    {
        o = new Offer();
    }

    
    
    @Override
    public void getBank() 
    {
        b = new RaiffeisenBank();
    }

    @Override
    public void getLoan() 
    {
        l = new BussinessLoan();
    }

    @Override
    public void createOffer() 
    {
        o.offer = "Bank: " + b.returnBank() + " Loan: " + l.returnLoan();
    }

    @Override
    public String returnOffer() 
    {
        return o.offer;
    }
    
}
