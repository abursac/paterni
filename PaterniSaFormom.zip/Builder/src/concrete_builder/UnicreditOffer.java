/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_builder;

import builder.Assistant;
import client.Offer;
import concrete_product.HomeLoan;
import concrete_product.UnicreditBank;

/**
 *
 * @author Aleksandar
 */
public class UnicreditOffer extends Assistant
{

    public UnicreditOffer() 
    {
        o = new Offer();
    }
    
    
    @Override
    public void getBank() 
    {
        b = new UnicreditBank();
    }

    @Override
    public void getLoan() 
    {
        l = new HomeLoan();
    }

    @Override
    public void createOffer() 
    {
        o.offer = "Bank: " + b.returnBank() + " Loan: " + l.returnLoan();
    }

    @Override
    public String returnOffer() 
    {
        return o.offer;
    }
    
}
