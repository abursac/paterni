/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_state;

import context.Context;
import state.State;

/**
 *
 * @author Aleksandar
 */
public class InjuredState implements State
{
    @Override
    public void doAction(Context context) {
      System.out.println("Player is in injured state");
      context.setState(this);	
   }

    /**
     *
     * @return
     */
    @Override
    public String currentState() 
    {
        return "Injured state";
    }

    
}
