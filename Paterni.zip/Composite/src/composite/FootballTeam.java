/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package composite;

import component.Athlete;
import java.util.ArrayList;

/**
 *
 * @author Aleksandar
 */
public class FootballTeam implements Athlete{

    ArrayList<Athlete> playerList = new ArrayList<>();
    
    @Override
    public void showAthleteInfo() 
    {
        playerList.forEach((a) -> {
            a.showAthleteInfo();
        });
    }
    
    public void addAthlete(Athlete a)
    {
        playerList.add(a);
    }
    
    public void removeAthlete(Athlete a)
    {
        playerList.remove(a);
    }
}
