/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import composite.FootballTeam;
import leaf.Footballer;
import leaf.Golfer;
import leaf.Tenniser;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    public static void main(String[] args) {
        Tenniser t = new Tenniser("Nick Kyrgios", 1);
        Golfer g = new Golfer("Tiger Woods", 2);
        Footballer f1 = new Footballer("Cristiano Ronaldo", 3);
        Footballer f2 = new Footballer("Lionel Messi", 4);
        Footballer f3 = new Footballer("Robert Lewandowski", 5);
        
        FootballTeam ft = new FootballTeam();
        ft.addAthlete(f1);
        ft.addAthlete(f2);
        ft.addAthlete(f3);
        
        t.showAthleteInfo();
        g.showAthleteInfo();
        ft.showAthleteInfo();
        
    }
}
