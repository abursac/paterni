/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visitor;

import concrete_element.Computer;
import concrete_element.KeyBoard;
import concrete_element.Monitor;
import concrete_element.Mouse;

/**
 *
 * @author Aleksandar
 */
public interface ComputerPartVisitor {
    public void visit(Computer computer);
    public void visit(Mouse mouse);
    public void visit(KeyBoard keyboard);
    public void visit(Monitor monitor);
}
