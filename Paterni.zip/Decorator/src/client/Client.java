/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import component.ManagementTeam;
import concrete_component.JoseMourinho;
import concrete_component.PepGuardiola;
import concrete_decorator.MikelArteta;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    public static void main(String[] args) {
        ManagementTeam mt1 = new JoseMourinho();
        System.out.println(mt1.getDescription() + " " + mt1.getCost() + "$");
        
        ManagementTeam mt2 = new PepGuardiola();
        mt2 = new MikelArteta(mt2);
        System.out.println(mt2.getDescription() + " " + mt2.getCost() + "$");
    }
}
