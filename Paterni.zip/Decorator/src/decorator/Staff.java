/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decorator;

import component.ManagementTeam;

/**
 *
 * @author Aleksandar
 */
public abstract class Staff extends ManagementTeam
{
    public abstract String getDescription();
}
