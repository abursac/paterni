/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_class;

import abstract_class.Player;

/**
 *
 * @author Aleksandar
 */
public class Footballer extends Player{

    @Override
    public void train() 
    {
        System.out.println("Practicing free kicks...");
    }

    @Override
    public void compete() 
    {
        System.out.println("Playing a match...");
    }

    @Override
    public void win() 
    {
        System.out.println("Winning Champions League!");
    }
    
}
