/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_class;

import abstract_class.Player;

/**
 *
 * @author Aleksandar
 */
public class Basketballer extends Player
{
    @Override
    public void train() 
    {
        System.out.println("Practicing three pointers...");
    }

    @Override
    public void compete() 
    {
        System.out.println("Playing in NBA Finals...");
    }

    @Override
    public void win() 
    {
        System.out.println("Winning the ring!");
    }
}
