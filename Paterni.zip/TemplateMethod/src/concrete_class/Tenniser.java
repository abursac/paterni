/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_class;

import abstract_class.Player;

/**
 *
 * @author Aleksandar
 */
public class Tenniser extends Player
{
    @Override
    public void train() 
    {
        System.out.println("Practicing serve...");
    }

    @Override
    public void compete() 
    {
        System.out.println("Playing in a Grand Slam...");
    }

    @Override
    public void win() 
    {
        System.out.println("Winning Wimbledon!");
    }
}
