/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstract_class;

/**
 *
 * @author Aleksandar
 */
public abstract class Player {
    public abstract void train();
    public abstract void compete();
    public abstract void win();
    
    public final void doTheProcess()
    {
        train();
        compete();
        win();
    }
}
