/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_aggregate;

import aggregate.Container;
import iterator.Iterator;

/**
 *
 * @author Aleksandar
 */
public class NameRepository implements Container{
    public String players[] = {"Ronaldo" , "Messi" ,"Neymar" , "Mbappe"};

   @Override
   public Iterator getIterator() {
      return new NameIterator();
   }

   private class NameIterator implements Iterator {

      int index;

      @Override
      public boolean hasNext() {
      
         if(index < players.length){
            return true;
         }
         return false;
      }

      @Override
      public Object next() {
      
         if(this.hasNext()){
            return players[index++];
         }
         return null;
      }		
   }
}
