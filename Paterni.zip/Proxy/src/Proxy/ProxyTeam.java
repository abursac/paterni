/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Proxy;

import RealSubject.RealTeam;
import Subject.Team;
import java.util.ArrayList;

/**
 *
 * @author Aleksandar
 */
public class ProxyTeam implements Team{
    
    private Team t = new RealTeam();
    private ArrayList<String> bannedPlayers;

    public ProxyTeam() {
        bannedPlayers = new ArrayList<>();
        bannedPlayers.add("Messi");
        bannedPlayers.add("Neymar");
        bannedPlayers.add("Baloteli");
    }

    @Override
    public void transfer(String player) throws Exception 
    {
        if(bannedPlayers.contains(player))
        {
            throw new Exception("Player is banned!");
        }
        t.transfer(player);
    }
    
}
