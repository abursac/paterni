/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import adapter.AnimalAdapter;
import concrete_adaptee.Cat;
import concrete_adaptee.Dog;
import target.AnimalToy;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    public static void main(String[] args) {
        Dog dog = new Dog();
        Cat cat = new Cat();
        
        AnimalAdapter at1 = new AnimalAdapter(dog);
        AnimalAdapter at2 = new AnimalAdapter(cat);
        
        at1.oglasiSe();
        at1.pomerajSe();
        at2.oglasiSe();
        at2.pomerajSe();
    }
}
