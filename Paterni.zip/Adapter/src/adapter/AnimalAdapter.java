/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

import adaptee.Animal;
import target.AnimalToy;

/**
 *
 * @author Aleksandar
 */
public class AnimalAdapter implements AnimalToy
{
    Animal a;

    public AnimalAdapter(Animal a) {
        this.a = a;
    }
    
    
    
    @Override
    public void pomerajSe() 
    {
        a.move();
    }

    @Override
    public void oglasiSe() 
    {
        a.makeSound();
    }
    
}
