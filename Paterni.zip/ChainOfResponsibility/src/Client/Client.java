/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import concrete_handler.Defender;
import concrete_handler.Forward;
import concrete_handler.Midfielder;
import handler.Player;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    private static Player getChainOfPlayers(){

      Defender def = new Defender(Player.DEFENDER);
      Midfielder mid = new Midfielder(Player.MIDFIELDER);
      Forward fwd = new Forward(Player.FORWARD);

      def.setNextPlayer(mid);
      mid.setNextPlayer(fwd);

      return def;	
   }
    
    public static void main(String[] args) {
        Player playerChain = getChainOfPlayers();

      playerChain.logMessage(Player.DEFENDER, 
         "He passed it slowly.");

      playerChain.logMessage(Player.MIDFIELDER, 
         "He sent an astonishing pass.");

      playerChain.logMessage(Player.FORWARD, 
         "He scored a beautiful goal.");
    }
}
