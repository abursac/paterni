/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_command.LightOnCommand;
import concrete_command.StereoOffCommand;
import concrete_command.StereoOnWithCDCommand;
import invoker.SimpleRemoteControl;
import receiver.Light;
import receiver.Stereo;

/**
 *
 * @author Aleksandar
 */
public class Client {
    public static void main(String[] args) 
    { 
        SimpleRemoteControl remote = 
                  new SimpleRemoteControl(); 
        Light light = new Light(); 
        Stereo stereo = new Stereo(); 
  
        // we can change command dynamically 
        remote.setCommand(new
                    LightOnCommand(light)); 
        remote.buttonWasPressed(); 
        remote.setCommand(new
                StereoOnWithCDCommand(stereo)); 
        remote.buttonWasPressed(); 
        remote.setCommand(new
                   StereoOffCommand(stereo)); 
        remote.buttonWasPressed(); 
     } 
}
