/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.util.ArrayList;
import java.util.List;
import memento.Memento;
import originator.Original;

/**
 *
 * @author Aleksandar
 */
public class Client {
     public static void main(String[] args)  
    { 
          
        List<Memento> savedPlayers = new ArrayList<Memento>(); 
   
        Original o = new Original(); 
   
        //time travel and record the eras 
        o.set("Ronaldo"); 
        savedPlayers.add(o.saveToMemento()); 
        o.set("Messi"); 
        savedPlayers.add(o.saveToMemento()); 
        o.set("Neymar"); 
        savedPlayers.add(o.saveToMemento()); 
        o.set("Mbappe"); 
   
        o.restoreFromMemento(savedPlayers.get(0));    
   
    } 
}
