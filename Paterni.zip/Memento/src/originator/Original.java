/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package originator;

import memento.Memento;

/**
 *
 * @author Aleksandar
 */
public class Original {
    private String player; 
   
    public void set(String player)  
    { 
        System.out.println("Setting player to " + player); 
        this.player = player; 
    } 
   
    public Memento saveToMemento()  
    { 
        System.out.println("Saving player to Memento"); 
        return new Memento(player); 
    } 
   
    public void restoreFromMemento(Memento memento)  
    { 
        player = memento.getSavedPlayer(); 
        System.out.println("Player restored from Memento: " + player); 
    } 
}
