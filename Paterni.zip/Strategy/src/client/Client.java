/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_strategy.OperationAdd;
import concrete_strategy.OperationDivide;
import concrete_strategy.OperationMultiply;
import concrete_strategy.OperationSubstract;
import context.Context;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    public static void main(String[] args) {
      Context context = new Context(new OperationAdd());		
      System.out.println("10 + 5 = " + context.executeStrategy(10, 5));

      context = new Context(new OperationSubstract());		
      System.out.println("10 - 5 = " + context.executeStrategy(10, 5));

      context = new Context(new OperationMultiply());		
      System.out.println("10 * 5 = " + context.executeStrategy(10, 5));
      
      context = new Context(new OperationDivide());		
      System.out.println("10 / 5 = " + context.executeStrategy(10, 5));
   }
}
