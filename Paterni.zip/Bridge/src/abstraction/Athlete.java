/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstraction;

import implementation.SportProcess;

/**
 *
 * @author Aleksandar
 */
public abstract class Athlete {
    protected SportProcess process1;
    protected SportProcess process2;
    
    protected Athlete(SportProcess p1, SportProcess p2)
    {
        this.process1 = p1;
        this.process2 = p2;
    }
    
    abstract public void doTheProcess();
}
