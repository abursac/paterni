/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package refined_abstraction;

import abstraction.Athlete;
import implementation.SportProcess;

/**
 *
 * @author Aleksandar
 */
public class Footballer extends Athlete
{

    public Footballer(SportProcess p1, SportProcess p2) {
        super(p1, p2);
    }
    
    
    @Override
    public void doTheProcess() 
    {
        System.out.println("Football player: ");
        process1.work();
        process2.work();
    }
    
}
