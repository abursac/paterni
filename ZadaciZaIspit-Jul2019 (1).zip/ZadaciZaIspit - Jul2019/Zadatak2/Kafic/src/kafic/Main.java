/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kafic;

import java.util.ArrayList;
import kafic.model.Caj;
import kafic.model.CrniSaMlekom;
import kafic.model.Espresso;
import kafic.model.Kafa;
import kafic.model.Nana;
import kafic.model.TurskaKafa;

/**
 *
 * @author Ilija Antovic
 */
public class Main {

    public static void main(String[] args) {
        ArrayList<Caj> cajevi=new ArrayList<Caj>();
        ArrayList<Kafa> kafe=new ArrayList<Kafa>();

        Caj cajOdNane1=new Nana();
        Caj crniCaj=new CrniSaMlekom();
        Caj cajOdNane2=new Nana();

        cajevi.add(cajOdNane1);
        cajevi.add(crniCaj);
        cajevi.add(cajOdNane2);

        Kafa espresso1=new Espresso();
        Kafa turskaKafa1=new TurskaKafa();
        Kafa turskaKafa2=new TurskaKafa();
        Kafa espresso2=new Espresso();

        kafe.add(espresso1);
        kafe.add(turskaKafa1);
        kafe.add(espresso2);
        kafe.add(turskaKafa2);

        kuvajKafe(kafe);

    }

    public static void kuvajKafe(ArrayList<Kafa> kafe){
        for (int i = 0; i < kafe.size(); i++) {
            kafe.get(i).kuvajKafu();
            System.out.println("---------------------------");
        }
    }

}
