/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kafic.model;

/**
 *
 * @author Ilija Antovic
 */
public interface Kafa {
    public void kuvajKafu();
}
