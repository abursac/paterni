/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kafic.model;

/**
 *
 * @author Ilija Antovic
 */
public class CrniSaMlekom implements Caj{
    public void staviVoduDaProkuva() {
        System.out.println("Kuvam 1,5 dl vode za crni caj sa mlekom");
    }

    public void dodajCaj() {
        System.out.println("Dodajem crni caj");
    }

    public void ubaciDodatke() {
        System.out.println("Dodajem secer i 0,5 dl mleka");
    }
}
