/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kafic.model;

/**
 *
 * @author Ilija Antovic
 */
public interface Caj {
    public void staviVoduDaProkuva();
    public void dodajCaj();
    public void ubaciDodatke();
}
