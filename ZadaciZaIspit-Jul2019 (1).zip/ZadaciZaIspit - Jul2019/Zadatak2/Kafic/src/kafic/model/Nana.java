/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kafic.model;

/**
 *
 * @author Ilija Antovic
 */
public class Nana implements Caj{

    public void staviVoduDaProkuva() {
        System.out.println("Kuvam 2dl vode za caj od Nane");
    }

    public void dodajCaj() {
        System.out.println("Dodajem kesicu caja od Nane");
    }

    public void ubaciDodatke() {
        System.out.println("Dodajem secer");
    }

}
