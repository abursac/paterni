/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kafic.model;

/**
 *
 * @author Ilija Antovic
 */
public class Espresso implements Kafa{

    public void napuniAparatKafom(){
        System.out.println("Punim aparat kafom");
    }

    public void ukljuciAparat(){
        System.out.println("Ukljucujem aparat");
    }
    public void kuvajKafu() {
        napuniAparatKafom();
        ukljuciAparat();
    }

}
