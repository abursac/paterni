/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kafic.model;

/**
 *
 * @author Ilija Antovic
 */
public class TurskaKafa implements Kafa{

    public void napuniDzezvuVodom(){
        System.out.println("Punim dzezvu za kafu");
    }

    public void ukljuciRinglu(){
        System.out.println("Ukljucujem ringlu");
    }

    public void dodajKafu(){
        System.out.println("Dodajem kafu");
    }

    public void kuvajKafu() {
        napuniDzezvuVodom();
        ukljuciRinglu();
        dodajKafu();
    }

}
